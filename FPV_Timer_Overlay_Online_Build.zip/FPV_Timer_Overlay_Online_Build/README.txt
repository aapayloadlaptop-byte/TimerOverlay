FPV Timer Overlay — online Windows build

You do NOT need Python installed on your PC. GitHub's hosted Windows runner installs Python temporarily and builds the EXE online.

1. Create a free GitHub account at https://github.com/ if you don't already have one.
2. Create a new repository. Public or private is fine.
3. Upload fpv_timer_overlay.py to the repository root.
4. In the repository, choose Add file > Create new file.
5. Name the file exactly: .github/workflows/build-windows.yml
6. Paste the workflow contents from the file included in this package at that path, then commit.
7. Open the Actions tab. Select "Build FPV Timer Overlay", click Run workflow.
8. When it finishes, open the successful run and download the "FPV_Timer_Overlay_Windows" artifact.
9. Extract the downloaded ZIP. Run FPV_Timer_Overlay.exe. Keep ffmpeg.exe in the same folder as the EXE.

The downloaded artifact contains both the app and FFmpeg, so no Python or separate FFmpeg installation is needed on your PC.

Note: GitHub Actions builds the Windows executable on a hosted Windows machine. The EXE is not built on your computer.
